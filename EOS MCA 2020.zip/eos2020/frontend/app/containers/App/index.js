/**
 *
 * App
 *
 * This component is the skeleton around the actual pages, and should only
 * contain code that should be seen on all pages. (e.g. navigation bar)
 */

import React from 'react';
import { Helmet } from 'react-helmet';
import styled from 'styled-components';
// import { Switch, Route } from 'react-router-dom';

// import HomePage from 'containers/HomePage/Loadable';
import FeaturePage from 'containers/FeaturePage/Loadable';
import NotFoundPage from 'containers/NotFoundPage/Loadable';
import 'bootstrap/dist/css/bootstrap.css';
import Navbar from 'components/Navbar/index'
import Slide from '../../components/Slider/reactSlick'
import SignUp from '../../components/SignUp/signup'
import Footer from '../../components/Footer/footer'
import Login from '../../components/Login/login'
import Register from '../../components/Registeration'
import Gallery from '../../components/Gallery/gallery'
import Profile from '../../components/profile/profile'
import ProductList from '../../components/filter/filter'
import ProductPage from '../../components/products/product'
import Cart from '../../components/Addcard/addcard'
import CartHeader from '../../components/Addcard/cartNavbar'
import Address from '../../components/Address/address'
import AddressHeader from '../../components/Address/addressHeader'
import Order from '../../components/Order/order'
import OrderDetails from '../../components/Order/orderDetails'
import {NavigationBars} from '../../components/Originals/header'
import UserSide from '../../components/Originals/userside'
import {Hospit} from '../../components/addproduct/adds';



//import GlobalStyle from '../../global-styles';
import {BrowserRouter as Router,Route,Switch} from 'react-router-dom'
var ReactDOM = require('react-dom');


export default function App() {
  return (
    <Router>
    <div>
<Switch>
<Route path='/' exact render={props =>
  <div>
    <Navbar />
    <Slide />
    <Gallery />
    <Footer />
  </div>
} />
<Route path='/register' exact render={props =>
  <div>
    <Navbar />
<Register/>
 <Footer />
  </div>
} />
  
<Route path='/signup' exact render={props =>
  <div>
    <Navbar />
<SignUp/>
 <Footer />
  </div>
} />
<Route path='/profile' exact render={props =>
  <div>
    <Navbar />
<Profile/>
 <Footer />
  </div>
} />
<Route path='/login' exact render={props =>
  <div>
    <Navbar />
<Login/>
 <Footer />
  </div>
} />
<Route path='/products' exact render={props =>
  <div>
    <Navbar />
<ProductList/>
 <Footer />
  </div>
} />
<Route path='/products/:product_code' exact render={props =>
  <div>
    <Navbar />
<ProductPage/>
 <Footer />
  </div>
} />
<Route path='/cart' exact render={props =>
  <div>
  <CartHeader />
<Cart/>
 <Footer />
  </div>
} />


<Route path='/address' exact render={props =>
  <div>
  <AddressHeader />
<Address />
 <Footer />
  </div>
} />

<Route path='/order' exact render={props =>
  <div>
    <Navbar />
<Order/>
 <Footer />
  </div>
} />

<Route path='/order/:orderId' exact render={props =>
  <div>
    <Navbar />
<OrderDetails />
 <Footer />
  </div>
} />
<Route path='/admin' exact render={props =>
  <div>
  <NavigationBars />
<UserSide/>

  </div>
} />
<Route path='/addproduct' exact render={props =>
  <div>
  <NavigationBars />
<UserSide/>
<Hospit/>
  </div>
} />


</Switch>


</div>
</Router>
  
  );
}
ReactDOM.render(App,document.getElementById('app'))