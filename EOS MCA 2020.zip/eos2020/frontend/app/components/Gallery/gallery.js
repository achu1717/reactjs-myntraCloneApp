import React,{Component} from 'react';
import {
    Card, Row, Col,Container, CardImg
  } from 'reactstrap';
  import {getAllGalleryImages} from '../../../ApiService'
  import './gallery.css'
  import imgss from './images/ss.png'
  
class gallery extends Component{
  state={
    gallery:[]
  }
  componentDidMount(){
    getAllGalleryImages().then(gallery=>
        gallery)
        .then(gallery=>this.setState({gallery}))
        
  }
  Image(){
    return this.state.gallery.map(gallery =>{ 
return(
  <Col lg="3">
 <a href="/products"><Card>
  <CardImg src={gallery.image}></CardImg>
    </Card></a>
  </Col>

)
    })
  }
  render(){


        return (   
          <div className="gallery">  
            <div className="container">
            <img id="posterimgs" src={imgss}></img>
              <img id="posterimg" src="https://bit.ly/2NM0DMO"></img>
             
              </div> 
             
       <Container fluid >
         <div className="heading">
           <h4 id="celebrate">CELEBRATE HERITAGE</h4>
          
         </div>
         
       <div className="row">   {this.Image()}</div>
      
      
        </Container>
       
        </div> 
        )
      
}
}
export default gallery;
