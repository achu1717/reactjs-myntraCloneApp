import React from 'react';
import { Button, Form, FormGroup, Label, Input, FormText } from 'reactstrap';
import { Component } from 'react';
import { editProfile,Profile } from '../../../ApiService';

class Register extends Component{
  constructor(props){
    super(props)
    this.state={
      first_name:'',
      last_name:'',
      gender:'',
      dob:'',
      bio:'',
      mobile:'',
      location:'',
      email:'' ,
      
    }
    this.onChange=this.onChange.bind(this)
    this.onSubmit=this.onSubmit.bind(this)
  }
  onChange(e){
    this.setState({[e.target.name]:e.target.value})
  }

  componentDidMount(){
    Profile().then(data=>data)
    .then(data=>this.setState({
      first_name:data.first_name,
      last_name:data.last_name,
      gender:data.gender,
      dob:data.dob,
      bio:data.bio,
      mobile:data.mobile,
      location:data.location,
    })
    
     ).catch(err=>{
       alert(err)
     }) }
  onSubmit(e){
   
    e.preventDefault()
    const reg={
      first_name:this.state.first_name,
      last_name:this.state.last_name,
      gender:this.state.gender,
      dob:this.state.dob,
      bio:this.state.bio,
      mobile:this.state.mobile,
      location:this.state.location,
    } 




    
    editProfile(reg)
    .then(res=>{alert("Changes Updated")
    window.location= '/profile'
  })
    .catch(err=>{
      alert("Update Cancelled")
    })
  //   e.preventDefault() 
   
  //        let first_name=this.state.first_name;
  //        let last_name=this.state.last_name
  //        let gender=this.state.gender
  //        let dob=this.state.dob
  //        let bio=this.state.bio
  //        let mobile=this.state.mobile
  //        let location=this.state.location
  //        let email=this.state.email
  //        editProfile(first_name, last_name, gender, dob, bio, mobile, location,email).then(this.props.history.push('/signup'))
  // }
  //   register(reg).then(res=>{
  //     alert(reg)
  //     this.props.history.push('/')
  //   })
  }

 
render()
{
  return (
    <Form className="container" noValidate onSubmit={this.onSubmit}>

    <FormGroup>
        <Label for="first_name">First Name</Label>
        <Input type="text" name="first_name" id="first_name" value={this.state.first_name} onChange={this.onChange} />
      </FormGroup>
      <FormGroup>
        <Label for="last_name">Last Name</Label>
        <Input type="text" name="last_name" id="last_name" value={this.state.last_name} onChange={this.onChange} />
      </FormGroup>

      <FormGroup tag="fieldset">
        <legend>Gender</legend>
        <FormGroup check>
          <Label check>
            <Input type="radio" name="gender" value="Male" onChange={this.onChange} />{' '}
            Male
          </Label>
        </FormGroup>
        <FormGroup check>
          <Label check>
            <Input type="radio" name="gender" value="Female" onChange={this.onChange}/>{' '}
            Female
          </Label>
        </FormGroup>
        <FormGroup check >
          <Label check>
            <Input type="radio" name="gender" value="Others" onChange={this.onChange} />{' '}
            Others
          </Label>
        </FormGroup>
      </FormGroup>


      <FormGroup>
        <Label for="exampleDate">Date of Birth</Label>
        <Input
          type="date"
          name="dob"
          id="exampleDate"
          placeholder="date placeholder"
          value={this.state.date}
          onChange={this.onChange}
        />
      </FormGroup>

      <FormGroup>
        <Label for="bio">Bio</Label>
        <Input type="text" name="bio" id="bio" value={this.state.bio} onChange={this.onChange} />
      </FormGroup>



      <FormGroup>
        <Label for="mobile">Mobile Number</Label>
        <Input
          type="number"
          name="mobile"
          id="mobile"
          value={this.state.mobile}
          onChange={this.onChange}
        />
      </FormGroup>


      <FormGroup>
        <Label for="location">Location</Label>
        <Input type="text" name="location" id="location"  value={this.state.location} onChange={this.onChange}/>
      </FormGroup>



      <Button type="submit">Submit</Button>

    </Form>
  );
}
}
export default Register;