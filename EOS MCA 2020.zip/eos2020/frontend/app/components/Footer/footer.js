import React from "react";
import { Jumbotron, Container } from "reactstrap";
import { Row, Col } from "reactstrap";
import "./footer.css";
import { Badge } from "react-bootstrap";
import facebooklogo from "./images/facebook.png"
import twitter from "./images/twitter_logo.png"
import youtube from './images/YOUTUBE.png';
import insta from './images/insta.png';
// import original from './images/original-stamp.png';
// import truck from './images/truck.png';
// import days from './images/30days.png';

// import { faHome } from "@fortawesome/free-solid-svg-icons";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

class footer extends React.Component {
  constructor(props) {
    super(props);

    this.state = {};
  }

  render() {
    return (
      <div> 
        <div  class="container">
          <button type="button" id="buttonabcd"><h5 id="backtop">Back to top</h5></button>
        </div>
        <Jumbotron fluid>
          <Container fluid className="text-center text-md-left">
            <Row>
            
              <Col XS lg="4">
                <ul className="list-unstyled">
                  <p>
                    <b>THE INDIA CRAFT HOUSE</b>
                  </p>
                  <li>
                    <a href="#">About Us</a>
                  </li>
                  <li>
                    <a href="#women">Mission</a>
                  </li>
                  <li>
                    <a href="#kids">Contact Us</a>
                  </li>
                  <li>
                    <a href="#home&living">Self with us</a>
                  </li>
                  <li>
                    <a href="#discover">Fair Trade</a>
                  </li>
                  <li>
                    <a href="#gift cards">Terms of Use</a>
                  </li>
                  <li>
                    <a href="#gift cards">Blog</a>
                  </li>
                  <li>
                    <a href="#gift cards">Site map</a>
                  </li>
                
                </ul>
              </Col>
              <Col XS lg="3">
                <ul className="list-unstyled">
                  <p>
                    <b>SHOP</b>
                  </p>
                  <li>
                    <a href="#contact us">My Acoount</a>
                  </li>
                  <li>
                    <a href="#faq">Reward Program </a>
                  </li>
                  <li>
                    <a href="#t&c">Gift Card</a>
                  </li>
                  <li>
                    <a href="#terms">Customized Orders</a>
                  </li>
                  <li>
                    <a href="#track">Bulk Orders</a>
                  </li>
                 
                </ul>
              </Col>
              <Col XS lg="3">
                <ul className="list-unstyled">
                  <p>
                    <b>HELP</b>
                  </p>
                  <li>
                    <a href="#contact us">Customer Service</a>
                  </li>
                  <li>
                    <a href="#faq">How To Order</a>
                  </li>
                  <li>
                    <a href="#t&c">Billing &  Payments</a>
                  </li>
                 
                  <li>
                    <a href="#shipping">Shipping & delivery</a>
                  </li>
                  <li>
                    <a href="#cancellation">Refund,Returns & Exchanges</a>
                  </li>
                  <li>
                    <a href="#returns">Discounts & Promotions</a>
                  </li>
                  <li>
                    <a href="#whitehad">FAQ'S</a>
                  </li>
    
                </ul>
              </Col>
           
              <Col XS lg="1" />
            </Row>
          </Container>
        </Jumbotron>
      </div>
    );
  }
}
export default footer;
