import React from 'react';
import styled from 'styled-components';
import './userside.css';
import { Nav, Navbar, Form, FormControl } from 'react-bootstrap';
const StyledSideNav=styled.div`

position:fixed;
height: 100%;
width:205px;
z-index:1;
top:3.4em;
background-color:#5699CD;
overflow-x: hidden;
padding-top:10px;
margin-top:11px;
`;
class SideNav extends React.Component{
    render(){
        return(
            <StyledSideNav>
            <div>
            <Nav.Item><Nav.Link href="/user"><img id="homeico" src="https://bit.ly/36ugzvS"></img><h5 className="sidemenu">Home</h5> </Nav.Link></Nav.Item>
            <Nav.Item><Nav.Link href="/addproduct"><img id="homeico2" src="https://bit.ly/2WVzegQ"></img><h6 className="sidemenu">Add Product</h6></Nav.Link></Nav.Item>
           

            <Nav.Item><Nav.Link href="/logout"><img id="homeico5" src="https://bit.ly/3giV2e8"></img><h6 className="sidemenu">Logout </h6></Nav.Link></Nav.Item>
            
           



                </div>
            </StyledSideNav>

        );
    }
}
export default class UserSide extends React.Component{
    render(){
        return(
<SideNav></SideNav>

        );
    }
}
