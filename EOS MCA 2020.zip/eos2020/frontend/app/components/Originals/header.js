// import React, { useState } from 'react';
// import "./style.css";
// import profile from './images/profile.png';
// import {Link} from 'react-router-dom';
// import {SideMenu} from 'react-sidemenu';
// import {
//   Collapse,
//   Navbar,
//   NavbarToggler,
//   NavbarBrand,
//   Nav,
//   NavItem,
//   NavLink,
//   UncontrolledDropdown,
//   DropdownToggle,
//   DropdownMenu,
//   DropdownItem,
//   Container,
//   Row,
//   Col,
//   Card,
//   CardText,
//   CardBody,
//   CardTitle,
//   CardLink,
//   Button,
//   Badge
// } from 'reactstrap';
// // import Icon from 'react-native-vector-icons/dist/FontAwesome';


// const header = (props) => {
//   const [isOpen, setIsOpen] = useState(false);

//   const toggle = () => setIsOpen(!isOpen);
  
// return (
//     <div>
//       <Navbar id="fullnav" expand="md" className="na1">
//         <NavbarBrand href="/admin"><h4 id="corona"> CORONA ALERT </h4>  </NavbarBrand>
//         <NavbarToggler onClick={toggle} />
//         <Collapse isOpen={isOpen} navbar >
//           <Nav className="mr-auto " navbar>
//             {/* <NavItem className="profile" style={{marginTop:10}}>
//             <img className="icon1" src={profile}/><br/><span className="sp1">welcome</span>
           
//             </NavItem>  */}

//            </Nav>
          
//         </Collapse>
//       </Navbar> 
 

//     </div>
//   );
// }

// export default header;
import React from 'react';
import { Nav, Navbar, Form, FormControl } from 'react-bootstrap';
import styled from 'styled-components';
import './style.css';
const Styles = styled.div`
  .navbar { background-color: #0F84E0; }
  a, .navbar-nav, .navbar-light .nav-link {
    color: black;
    &:hover { color: white; }
  }
  .navbar-brand {
    font-size: 1.4em;
    color: black;
    &:hover { color: white; }
  }
  .form-center {
    position: absolute !important;
    left: 25%;
    right: 25%;
  }
`;
export const NavigationBars = () => (
  <Styles>
    <Navbar expand="lg">
      <Navbar.Brand id="corona" href="/admin">Thanjore Admin</Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav"/>
     
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="ml-auto">
         <Nav.Item><Nav.Link href="/logout"><img id="profile" src="https://bit.ly/3e4CVGY"></img></Nav.Link></Nav.Item>
  
        </Nav>
      </Navbar.Collapse>
    </Navbar>
  </Styles>
)