import React from 'react';
import styled from 'styled-components';
import Button from 'react-bootstrap/Button'
import './index.css';
const GridWrapper = styled.div`
  display: grid;
  grid-gap: 10px;
  margin-top: 1em;
  margin-left: 200px;
  margin-right: 6em;
  grid-template-columns: repeat(12, 1fr);
  grid-auto-rows: minmax(25px, auto);
  margin-top:-8px;
`; 
export const Hospit= () => (
  <GridWrapper>
     <div className="container new">
<h4>Add Product</h4>
<h5>Product name <sup>*</sup></h5>
<input type="text"></input>
     </div>

  </GridWrapper>
)