import React, { useState } from 'react';
import './index.css';
import logo from './images/abc.png';
import bag from './images/bag.png'
import profile from './images/profile.png'
import wishlist from './images/wishlist.png'
import search from './images/search.png';
import {Link} from 'react-router-dom';
import FontAwesome from 'react-fontawesome'
 import faStyles from 'font-awesome/css/font-awesome.css'
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavLink,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  NavbarText,
 Modal, ModalHeader, ModalBody, ModalFooter,
  Container, Row, Col ,
  Card, Button, CardHeader, CardFooter, CardBody,
  CardTitle, CardText,CardLink
} from 'reactstrap';

// import {
//   BrowserRouter as Router,
//   Switch,
//   Route,
//   Link
// } from "react-router-dom";

const Example = (props) => {
  const {
    buttonLabel,
    className
  } = props;

  const [isOpen, setIsOpen] = useState(false);

  const toggle = () => setIsOpen(!isOpen);

 

 const logOut=(e)=> {
    e.preventDefault()
    localStorage.removeItem('Token')
   window.location='/'
  }

  return (
      

    <div>
      <Navbar expand="md" className="navbar">
        <NavbarBrand href="/"><img src={logo} className="logo"></img><h4 id="headingss">Thanjore Craft</h4></NavbarBrand>
        <NavbarToggler onClick={toggle} />
        <Collapse isOpen={isOpen} navbar>
          <Nav className="mr-auto navitems" navbar>
          {/* <NavItem>
            <UncontrolledDropdown nav inNavbar>
            <DropdownToggle nav ><NavLink href="#" className="link1 men">MEN</NavLink></DropdownToggle>
              <DropdownMenu>
              <Container>
              <Row>
                <Col>
                <Link to='/products'>
                <DropdownItem className="menh">Top Wear</DropdownItem></Link>
                <DropdownItem>T-Shirt</DropdownItem>
                <DropdownItem>Casual Shirts</DropdownItem>
                <DropdownItem>Formal Shirts</DropdownItem>
                <DropdownItem>Sweatshirts</DropdownItem>
                <DropdownItem>Sweaters</DropdownItem>
                <DropdownItem>Jackets</DropdownItem>
                <DropdownItem>Blazers & Coats</DropdownItem>
                <DropdownItem>Suits</DropdownItem>
                <DropdownItem>Rain Jackets</DropdownItem>
                 <DropdownItem divider />
                <DropdownItem className="menh">Indian & Festive Wear</DropdownItem>
                <DropdownItem>Sherwanis</DropdownItem>
                <DropdownItem>Kurtas & Kurta Sets</DropdownItem>
                <DropdownItem>Nehru Jackets</DropdownItem>
                <DropdownItem>Dhotis</DropdownItem>
                </Col>
                <Col className="even">
                <DropdownItem className="menh">Bottomwear</DropdownItem>
                <DropdownItem>Jeans</DropdownItem>
                <DropdownItem>Casual Trousers</DropdownItem>
                <DropdownItem>Formal Trousers</DropdownItem>
                <DropdownItem>Shorts</DropdownItem>
                <DropdownItem>Track Pants & Joggers</DropdownItem>
                <DropdownItem divider />
                <DropdownItem className="menh">Innerwear & Sleepwear</DropdownItem>
                <DropdownItem>Briefs & Trunks</DropdownItem>
                <DropdownItem>Boxers</DropdownItem>
                <DropdownItem>Vests</DropdownItem>
                <DropdownItem>Sleepwear & Loungewear</DropdownItem>
                <DropdownItem divider />
                <DropdownItem className="menh">Plus Size</DropdownItem>
                </Col>
                <Col>
                <DropdownItem className="menh">Footwear</DropdownItem>
                <DropdownItem>Casual Shoes</DropdownItem>
                <DropdownItem>Sports Shoes</DropdownItem>
                <DropdownItem>Formal Shoes</DropdownItem>
                <DropdownItem>Sneakers</DropdownItem>
                <DropdownItem>Sandals & Floaters</DropdownItem>
                <DropdownItem>Flip Flops</DropdownItem>
                <DropdownItem>Socks</DropdownItem>
                <DropdownItem divider />
                <DropdownItem className="menh">Personal Care & Grooming</DropdownItem>
                <DropdownItem className="menh">Sunglasses & Frames</DropdownItem>
                <DropdownItem className="menh">Watches</DropdownItem>
                </Col>
                <Col className="even">
                <DropdownItem className="menh">Sports & Active Wear</DropdownItem>
                <DropdownItem>Sports Shoes</DropdownItem>
                <DropdownItem>Sports Sandals</DropdownItem>
                <DropdownItem>Active T-Shirts</DropdownItem>
                <DropdownItem>Tracksuits</DropdownItem>
                <DropdownItem>Track Pants & Joggers</DropdownItem>
                <DropdownItem divider />
                <DropdownItem className="menh">Gadgets</DropdownItem>
                <DropdownItem>Smart Wearables</DropdownItem>
                <DropdownItem>Fitness Gadgets</DropdownItem>
                <DropdownItem>Headphones</DropdownItem>
                <DropdownItem>Speakers</DropdownItem>
                </Col>
                <Col>
                <DropdownItem className="menh">Fashion Accessories</DropdownItem>
                <DropdownItem>Wallets</DropdownItem>
                <DropdownItem>Belts</DropdownItem>
                <DropdownItem> Perfumes & Body Mists</DropdownItem>
                <DropdownItem>Trimmers</DropdownItem>
                <DropdownItem>Deodorants</DropdownItem>
                <DropdownItem>Ties, Cufflinks & Pocket Squares</DropdownItem>
                <DropdownItem>Caps & Hats</DropdownItem>
                <DropdownItem>Accessory Gift Sets</DropdownItem>
                <DropdownItem>Mufflers, Scarves & Gloves</DropdownItem>
                <DropdownItem>Phone Cases</DropdownItem>
                <DropdownItem>Rings & Wristwear</DropdownItem>
                 <DropdownItem divider />
                <DropdownItem className="menh">Helmets</DropdownItem>
                <DropdownItem className="menh">Bags & Backpacks</DropdownItem>
                <DropdownItem className="menh">Luggages & Trolleys</DropdownItem>
                </Col>
                </Row>
                </Container>
              </DropdownMenu>
             </UncontrolledDropdown>
            </NavItem> */}
            <NavItem>
            <div class="input-group search">
        <div class="input-group-btn">
          <button class="btn search-button" type="submit">
          <img src={search} className="searchicon"></img><br />
          </button>
        </div>
        <input type="text" class="form-control" placeholder="Search" name="search" id="search" />
      </div>
            </NavItem>
            <Link to='/signup'>  <Button outline  id="loginaa">LOGIN</Button></Link>
          {/* <Link to='/login'>  <Button outline >Login</Button></Link> */}
            <div className="logos">
            {/* <NavItem className="profile">
            <img src={profile} className="searchicon"></img><br />
                profile
                <div className="profileCard">
      <Card>
        <h6>WELCOME</h6>
        <p>To access account and manage orders</p>
        <div className="button">
         
       
        </div>
        <hr/>
  
        <CardLink href="/order" style={{marginLeft:"20px"}}> Orders</CardLink>
        <CardLink href="/Wishlist/"> Wishlist</CardLink>
        <CardLink href="/GiftCards/"> Gift Cards</CardLink>
        <CardLink href="/ContactUs/"> Contact Us</CardLink>
        <CardLink href="/MyntraInsider/"> Myntra Insider</CardLink><hr/>
        <CardLink href="/MyntraCredit/" style={{marginLeft:"20px"}}>  Myntra Credit</CardLink>
        <CardLink href="/Coupons/">  Coupons</CardLink>
        <CardLink href="/SavedCards/"> Saved Cards</CardLink>
        <CardLink href="/address/">  Saved Addresses</CardLink>
        <CardLink href="/profile/">  Profile</CardLink>
        <CardLink href="" onClick={logOut.bind(this)}>  Log Out</CardLink>


      </Card>


    </div>
            </NavItem> */}
            {/* <NavItem className="wishlist">
            <img src={wishlist} className="searchicon"></img><br />
                Wishlist
                <div className="profileCard">
                </div> */}
            {/* </NavItem> */}
           <Link to="/cart"> <NavItem className="bag">
            <img src={bag} id="bagss" className="searchicon"></img><br />
                <h6 id="bagsss">Bag</h6>
                <div className="profileCard">
                </div>
            </NavItem></Link>
            </div>
          </Nav>
          
        </Collapse>
      </Navbar>
    </div>
  

  );
}

export default Example;