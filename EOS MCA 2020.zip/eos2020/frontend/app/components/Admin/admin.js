import React, { Component } from 'react'

export class admin extends Component {
  render() {
    return (
      <div>
        <h4>hi</h4>
      </div>
    )
  }
}

export default admin

